/* ==========================================================================
   I - Phần define resources :
=============================================================================*/
1. Mục tổng quan
	 - Nền tảng : Có thể chạy 2 nền tảng PC mà Mobile, lưu ý 2 nền tảng không nên dùng chung thư mục profiles. Ví dụ chạy Mobile thì dùng profiles ProfileMobile, chạy Pc thì dùng profiles ProfilePC.
	 - Restore Cookie : Khuyến khích Tool đã tự động tạo sẵn profile nên không cần dùng chức năng này. Nếu chọn có thì tool sẽ lấy cookie cũ được lưu trong database cột Cookie để import.
	 - Số lần chạy : Lưu ý 1 chút ở phần này để view được đều nên em đã code thuật toán trả luồng liên lục, do đó khi đã Tick vào "Xem video" thì số lần chạy sẽ là vô hạn. Nên khi đã tick vào xem video thì không thể tự chỉnh được số lần chạy nữa.
2. Mục Tuỳ chỉnh video
	 - View từ trang chủ : Sẽ tính theo % từ 1-100 - Tool sẽ sử dụng thủ thuật ép link để ép từ trang chủ tới video chính cần xem.
	 - View từ đề xuất : Sẽ tính theo % từ 1-100  - Tool sẽ sử dụng thủ thuật ép link để ép từ video đề xuất tới video chính cần xem. (View đề xuất được thêm Video ID ở bảng Recommend trong database).
	 - View từ search : Sẽ tính theo % từ 1-100 - Ở mục view từ search Tool sẽ không dùng thủ thuật để ép link mà thay vào đó sẽ chia ra 2 dạng để search.  Khi tìm thấy video sẽ click vào xem, không tìm thấy sẽ tắt luồng.
	   + Search theo từ khoá, title,... : Có thể tuỳ chỉnh trong bảng Video mục Tiêu đề video.
	   + Search theo từ khoá, title,... + Id kênh : Có thể tuỳ chỉnh từ khoá, title và ID của kênh trong bảng Video mục Tiêu đề video.
	 - Max Speed : Bao gồm các thủ thuật làm tăng hiệu năng của tool
	   + Chất lượng video : Xem video ở chế độ 144p.
	   + Màn hình trắng lúc xem video.
	   + Không load hình ảnh thumbnail.
	 - Tỷ lệ % bình luận : Có thể thêm bình luận ở file list_comments.txt, Tool sẽ bốc random 1 dòng để comment. Comment sẽ được thực hiện dựa theo tỷ lệ % nhập vào.

/* ==========================================================================
	II - Kịch bản chạy tool.
============================================================================= */
 	 - B1 : Tool sẽ vào kiểm tra login, nếu login thành công sẽ tiến hành xem video. Load trang chủ và xem video random bất kì tại trang chủ, thời gian xem được cài đặt ở Mục Tuỳ chỉnh video (Thời gian tối thiểu [Tối đa] xem video random).
 	 - B2 : Sau khi xem video ở trang chủ, tool sẽ tiến hành chọn random giữa 3 cách chạy (Chạy search, chạy view đề xuất, chạy view từ trang chủ), thời gian xem được cài đặt ở Mục Tuỳ chỉnh video (Thời gian tối thiểu [Tối đa] xem video chính).
 	    + Chạy Search : Search video theo 2 dạng (Search ID kênh - có và không). Nếu có sẽ tiến hành xem video, nếu không thì off luồng. (Khuyến khích nên chạy view theo dạng search vì nó an toàn không dùng thủ thuật)
 	    + Chạy View đề xuất : Tool sẽ tiến hành bốc random bất kì trong bảng Recommend, sau đó ép link đến video cần xem. (Test trên thống kê thời gian thực ra được video đề xuất).
 	    + Chạy View từ trang chủ : Tool sẽ tiến hành click vào 1-10 kết quả đầu tiên ở trang chủ, sau đó ép link đến video cần xem. (Test trên thống kê thời gian thực ra được Các tính năng duyệt xem).
 	- B3 : Khi đã xem xong video chính ở bước 2 (Chạy View đề xuất, chạy View từ trang chủ) hoặc tìm thấy video lúc search và bấm vào xem. Thì tiến hành click vào video đề xuất bên dưới video chính để xem. Thời gian xem giống bước 1 (Thời gian tối thiểu [Tối đa] xem video random).

/* ==========================================================================
	III - Trạng thái Login Mail
============================================================================= */
	- Mail chưa login : 0
	- Mail login thành công : 1
 	- Mail dính captcha : 10
 	- Mail sai mật khẩu : Thử lần lượt từng mật khẩu trong file new_passwords.txt, thử tối đa 3 lần. Sai thì trạng thái = 99
 	- Mail yêu cầu đổi mật khẩu : 99
 	- Lựa chọn số điện thoại khôi phục : 3
 	- Verify phone : 2
 	- Mail login thành công nhưng bị die youtube : 8
 	- Mail chết : 7

/* ==========================================================================
	IV - Một số lưu ý update bản BAS ver 64bit
============================================================================= */
	- Sử dụng bản Chrome mới nhất Version 113.0.5672.64 (Official Build) (64-bit)
	- Phiên bản trình duyệt X64.
	- Thêm chế độ trình duyệt an toàn : Safe Browsing
